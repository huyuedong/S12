from django.apps import AppConfig


class MonitorfailurestatisticsConfig(AppConfig):
    name = 'MonitorFailureStatistics'
